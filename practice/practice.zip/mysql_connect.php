<?php
    $host = 'localhost';
    $user = 'root';
    $pw = 'apmsetup';
    $dbName = 'roleDB';

    $mysql = mysqli_connect($host, $user, $pw, $dbName);
?>